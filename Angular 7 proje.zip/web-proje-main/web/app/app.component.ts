import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: '<div class="container"><app-product-list></app-product-list></div>',
  styles: []
})
export class AppComponent { }
